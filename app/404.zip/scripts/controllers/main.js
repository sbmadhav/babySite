'use strict';

angular.module('angNewsApp')
  .controller('MainCtrl', function ($scope) {
    $scope.children = [{
    	'name':'Vishnu',
    	'age':2
    },{
    	'name':'Ravi',
    	'age':2
    },{
    	'name':'Manish',
    	'age':2
    },{
    	'name':'Ahsha',
    	'age':2
    },{
    	'name':'varosa',
    	'age':2
    },{
    	'name':'Omg',
    	'age':2
    }
    ];

    $scope.slectChild=function(){
    	alert(this);
    };
     
  });
